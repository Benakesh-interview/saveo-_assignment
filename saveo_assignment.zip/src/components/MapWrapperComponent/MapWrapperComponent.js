import React from "react";
import { compose, withProps } from "recompose";
import { withScriptjs, withGoogleMap } from "react-google-maps";
import GoogleMapComponent from "../GoogleMapComponent/GoogleMapComponent";
import { GoogleMapsAPI } from "../../client_config";

const MapWrapperComponent = compose(
  withProps({
    googleMapURL:
      `https://maps.googleapis.com/maps/api/js?key=${GoogleMapsAPI}&v=3.exp&libraries=geometry,drawing,places`,
    loadingElement: <div style={{ height: `100%` }} />,
    containerElement: <div style={{ height: `400px` }} />,
    mapElement: (
      <div
        className="mapBorder"
        style={{ height: `100%`}}
      />
    ),
  }),
  withScriptjs,
  withGoogleMap
)((props) => <GoogleMapComponent />);

export default MapWrapperComponent;
