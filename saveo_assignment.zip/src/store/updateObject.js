export const UpdateObjects = (oldObject, newObject) => {
    return {
        ...oldObject,
        ...newObject
    };
};
