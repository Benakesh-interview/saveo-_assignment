import { createStore, applyMiddleware, combineReducers } from "redux";
import thunk from "redux-thunk";
import mapReducer from "./mapReducer";
const logger = ({ getState }) => {
    return (next) => (action) => {
        console.log("will dispatch", action);
        const returnValue = next(action);
        console.log("state after dispatch", getState());
        return returnValue;
      };
  };

  const rootReducer = combineReducers({
      mapReducer:mapReducer
  });

  
const Store = createStore(rootReducer, applyMiddleware(logger, thunk));
export default Store;