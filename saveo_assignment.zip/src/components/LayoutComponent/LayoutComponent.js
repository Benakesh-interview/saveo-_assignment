import React, { Component } from "react";
import { connect } from "react-redux";
import { showRoute, updateMarker, fetchMarker } from "../../store/mapAction";
import MapWrapperComponent from "../MapWrapperComponent/MapWrapperComponent";

import "./LayoutComponent.css";
class LayoutComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      markers: [],
      title: "",
      lat: "",
      lng: "",
      formError: {
        title: "",
        lat: "",
        lng: "",
      },
    };
  }

  onChangeHandler = (e) => {
    const { name, value } = e.target;
    const { formError } = this.state;
    switch (name) {
      case "title":
        value.trim() === "" ? (formError.title = "") : (formError.title = "");
        break;
      case "lat":
        value.trim() === "" ? (formError.lat = "") : (formError.lat = "");
        break;
      case "lng":
        value.trim() === "" ? (formError.lng = "") : (formError.lng = "");
        break;
      default:
        break;
    }
    this.setState({ [name]: value, formError });
  };
  onAddLocation = (e) => {
    e.preventDefault();
    const { formError } = this.state;
    if (this.state.title.trim() === "") {
      formError.title = "Please enter a location name";
    } else {
      formError.title = "";
    }
    if (this.state.lat.trim() === "") {
      formError.lat = "Please enter a latitude";
    } else {
      formError.lat = "";
    }
    if (this.state.lng.trim() === "") {
      formError.lng = "Please enter a longitude";
    } else {
      formError.lng = "";
    }
    this.setState(
      {
        formError,
      },
      () => {
        const isEmpty = Object.values(this.state.formError).every(
          (x) => x === null || x === ""
        );
        if (isEmpty) {
          let marker = this.props.markers;
          marker.push({
            title: this.state.title,
            lat: parseFloat(this.state.lat),
            lng: parseFloat(this.state.lng),
          });
          this.props.onUpdateMarker(marker);
          setTimeout(() => {
            this.setState({
              markers: this.props.markers,
              title: "",
              lat: "",
              lng: "",
              formError: {
                title: "",
                lat: "",
                lng: "",
              },
            });
          }, 500);
        }
      }
    );
  };
  onShowRoute = (e) => {
    e.preventDefault();
    this.props.onShowRoutes(this.props.markers);
  };
  render() {
    return (
      <React.Fragment>
        <button className="home-btn">HOME</button>
        <div className="main-container">
          <div className="map-container">
            <div className="map-header-form">
              <form className="main-form" onSubmit={this.onAddLocation}>
                <div className="form-fields">
                  <div>
                    <label>Location Name</label>
                    <input
                      placeholder="Location"
                      type="text"
                      name="title"
                      value={this.state.title}
                      onChange={this.onChangeHandler}
                    />
                    <span className="error">{this.state.formError.title !== ""?this.state.formError.title:""}</span>
                  </div>
                  <div>
                    <label>Enter Lattitude</label>
                    <input
                      placeholder="Lat"
                      type="text"
                      name="lat"
                      value={this.state.lat}
                      onChange={this.onChangeHandler}
                    />
                        <span className="error">{this.state.formError.lat !== ""?this.state.formError.lat:""}</span>
                  </div>
                  <div>
                    <label>Enter Longitude</label>
                    <input
                      placeholder="Lon"
                      type="text"
                      name="lng"
                      value={this.state.lng}
                      onChange={this.onChangeHandler}
                    />
                        <span className="error">{this.state.formError.lng !== ""?this.state.formError.lng:""}</span>
                  </div>
                </div>
                <button type="submit" className="add-btn">
                  Add
                </button>
              </form>
            </div>
            <div className="content">
              <div className="all-coordinates">
                <h1>All Co-ordinates:</h1>
                <table className="table">
                  <thead>
                    <tr>
                      <th style={{ color: "#123043" }}>My Co-ordinates</th>
                      <th className="lat">Latitude</th>
                      <th className="lon">Longitude</th>
                    </tr>
                  </thead>
                  <tbody>
                    {this.props.showRoute &&
                      this.props.markers &&
                      this.props.markers.length > 0 &&
                      this.props.markers.map((location, index) => (
                        <tr key={index}>
                          <td style={{ color: "#123043" }}>
                            {index + 1}) {location.title}
                          </td>
                          <td style={{ color: "#000000" }}>{location.lat}</td>
                          <td style={{ color: "#000000" }}>{location.lng}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
                <button className="route-btn" onClick={this.onShowRoute}>
                  show route
                </button>
              </div>
              <div className="main-map">
                <MapWrapperComponent />
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    showRoute: state.mapReducer.showRoute,
    markers: state.mapReducer.markers,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onUpdateMarker: (marker) => dispatch(updateMarker(marker)),
    onShowRoutes: (marker) => dispatch(showRoute(marker)),
    fetchMarker: () => dispatch(fetchMarker()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(LayoutComponent);
