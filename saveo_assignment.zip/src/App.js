import React from 'react';
import { Route, Router, Switch, withRouter } from 'react-router';
import LayoutComponent from './components/LayoutComponent/LayoutComponent';
const App = (props) => {
  return (
    <Router history={props.history}>
      <Switch>
        <Route path="/" exact component={LayoutComponent} />
      </Switch>
    </Router>
  );
}
 
export default withRouter(App);