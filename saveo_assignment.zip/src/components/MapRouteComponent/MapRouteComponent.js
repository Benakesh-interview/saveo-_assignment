import React, { Component } from "react";
import DirectionsRenderer from "react-google-maps/lib/components/DirectionsRenderer";
import { connect } from "react-redux";
class MapRouteComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      directions: null,
      error: null,
    };
  }
  render() {
    var wait = false;
    const waypoints = this.props.markers.map((item) => ({
      location: { lat: item.lat, lng: item.lng },
    }));
    const origin = waypoints.shift().location;
    const destination = waypoints.pop().location;
    const directionsService = new window.google.maps.DirectionsService();
    directionsService.route(
      {
        origin: origin,
        destination: destination,
        travelMode: window.google.maps.TravelMode.DRIVING,
        waypoints: waypoints,
      },
      (result, status) => {
        if (status === window.google.maps.DirectionsStatus.OK) {
          this.setState({
            directions: result,
          });
        } else if (
          status == window.google.maps.GeocoderStatus.OVER_QUERY_LIMIT
        ) {
          wait = true;
          setTimeout("wait = true", 2000);
        } else {
          this.setState({ error: result });
        }
      }
    );
    return <DirectionsRenderer directions={this.state.directions} />;
  }
}
const mapStateToProps = (state) => {
  return {
    showRoute: state.mapReducer.showRoute,
    markers: state.mapReducer.markers,
  };
};
export default connect(mapStateToProps)(MapRouteComponent);
