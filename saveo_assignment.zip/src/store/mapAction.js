
export const showRoutes=(value)=>{
    return {
        type:"SHOW_ROUTES",
        markers:value
    }
}
export const updateMarkers=(marker)=>{
    return {
        type:"UPDATE_MARKER",
        markers:marker
    }
}
export const fetchMark=()=>{
    return {
        type:"FETCH_MARKER"
    }
}

export const showRoute =(value)=>{
    return (dispatch)=>{
        dispatch(showRoutes(value));
    }
}

export const updateMarker=(marker)=>{
    return (dispatch)=>{
        console.log("marker---",marker)
        dispatch(updateMarkers(marker));
    }
}

export const fetchMarker=()=>{
    return (dispatch)=>{
        dispatch(fetchMark());
    }
}