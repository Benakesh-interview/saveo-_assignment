import { UpdateObjects } from "./updateObject"


const initialState={
    showRoute:false,
    markers:[]
}

const showRoutes=(state,action)=>{
    return UpdateObjects(state,{
        showRoute:true,
        markers:action.markers
    })
}

const updateMarker=(state,action)=>{
    return UpdateObjects(state,{
        showRoute:false,
        markers:action.markers
    })
}

const mapReducer =(state=initialState,action=null)=>{
    switch(action.type){
        case "UPDATE_MARKER": return updateMarker(state,action);
        case "SHOW_ROUTES": return showRoutes(state,action);
        case "FETCH_MARKER":return state;
        default:return state;
    }
}

export default mapReducer;