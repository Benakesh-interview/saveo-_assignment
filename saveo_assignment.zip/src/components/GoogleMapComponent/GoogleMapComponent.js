import React, { Component, createRef } from "react";
import { GoogleMap, Marker } from "react-google-maps";
import InfoBox from "react-google-maps/lib/components/addons/InfoBox";
import axios from "axios";
import { connect } from "react-redux";
import { showRoute, updateMarker } from "../../store/mapAction";
import MapRouteComponent from "../MapRouteComponent/MapRouteComponent";
import markerBlack from '../../assets/marker.png';
class GoogleMapComponent extends Component {
  constructor(props) {
    super(props);
    this.myMap = createRef();
    this.state = {
      markers: this.props.markers,
      coords: {
        lat: 12.9634,
        lng: 77.5855,
      },
      selectedMarker: null,
      directions: null,
      zoom: 8,
      onMarkerHover: null,
      loading: false,
    };
  }
  UNSAFE_componentWillMount() {
    if (localStorage.getItem("marker")) {
      let marker = this.state.marker.splice();
      marker.push(...localStorage.getItem("marker"));
    }
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((success, err) => {
        if (err) {
          console.log("geolocation error");
        }
        if (success) {
          let coords = {
            lat: success.coords.latitude,
            lng: success.coords.longitude,
            title: "Bengaluru",
          };
          let marker = this.props.markers.splice();
          marker.push(coords);
          this.props.onUpdateMarker(marker);

          this.setState({
            coords,
            markers: marker,
          });
        }
      });
    }
    navigator.geolocation.watchPosition(
      (pos) => {
        console.log("I'm tracking");
      },
      (error) => {
        if (error.code == error.PERMISSION_DENIED) {
          this.getDefaultLocation();
        }
      }
    );
  }

  getDefaultLocation = () => {
    this.setState(
      {
        loading: true,
      },
      () => {
        axios
          .get("https://ipapi.co/json/")
          .then((response) => {
            if (
              response &&
              response.data &&
              (response.status === "200" || response.status === 200)
            ) {
              let coords = {
                title: response.data.city,
                lat: response.data.latitude,
                lng: response.data.longitude,
              };
              let marker = this.props.markers.splice();
              marker.push(coords);
              this.props.onUpdateMarker(marker);

              this.setState({
                coords,
                markers: marker,
              });
            }
          })
          .catch((error) => {
            console.log("internal server error");
          });
      }
    );
  };
  zoomChangedHandler = () => {
    this.setState(
      {
        zoom: this.map.getZoom(),
      },
      () => {
        this.setState({
          markers: this.props.markers,
        });
      }
    );
  };
  onMarkerOver = (item) => {
    this.setState({
      selectedMarker: item,
    });
  };
  render() {
    return (
      <GoogleMap
        ref={(map) => {
          this.map = map;
        }}
        onZoomChanged={this.zoomChangedHandler}
        defaultOptions={{
          fullscreenControl: false,
          gestureHandling: "greedy",
          disableDoubleClickZoom: true,
          streetViewControl: false,
          minZoom: 4,
          maxZoom: 18,
        }}
        defaultZoom={this.state.zoom}
        center={this.state.coords}
      >
        {this.state.markers.map((item, index) => (
          <Marker
            key={index}
            position={{ lat: item.lat, lng: item.lng }}
            onMouseOver={() => this.onMarkerOver(item)}
            onMouseOut={() => this.onMarkerOver(null)}
            // icon={ {
            //   url: markerBlack,
            //   scale: 0.02,
            //   strokeWeight: 0,
            //   scaledSize: new window.google.maps.Size(40, 28),
            // }}
          />
        ))}
        {this.state.selectedMarker && (
          <InfoBox
            onCloseClick={() => this.onMarkerOver(null)}
            defaultPosition={
              new window.google.maps.LatLng(
                this.state.selectedMarker.lat,
                this.state.selectedMarker.lng
              )
            }
          >
            <h2>{this.state.selectedMarker.title}</h2>
          </InfoBox>
        )}
        {this.props.showRoute ? (
          <MapRouteComponent
            mapRef={this.myMap}
            showRoute={this.props.showRoute}
          />
        ) : (
          ""
        )}
      </GoogleMap>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    showRoute: state.mapReducer.showRoute,
    markers: state.mapReducer.markers,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onUpdateMarker: (marker) => dispatch(updateMarker(marker)),
    onShowRoutes: () => dispatch(showRoute()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(GoogleMapComponent);
